<?php
/**
 * Created by PhpStorm.
 * User: seedteam
 * Date: 24.05.20
 * Time: 15:41
 */
$mod_strings['LBL_SELECT_SQL'] = 'Select in query';