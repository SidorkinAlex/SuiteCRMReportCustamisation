<?php
/**
 * Created by PhpStorm.
 * User: seedteam
 * Date: 24.05.20
 * Time: 15:30
 */
$dictionary['AOR_Field']['fields']['select_sql']=[
    'name' => 'select_sql',
    'vname' => 'LBL_SELECT_SQL',
    'type' => 'text',
    'comment' => 'SELECT',
    'rows' => 6,
    'cols' => 80,
];