<?php 
 //WARNING: The contents of this file are auto-generated


/**
 * Created by PhpStorm.
 * User: seedteam
 * Date: 20.01.21
 * Time: 23:13
 */
$mod_strings['LBL_SHOW_SQL'] = 'display full request';
?>